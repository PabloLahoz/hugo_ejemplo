+++
description = "Show rrrambl'n 'n a single tab"
title = "Tab"
+++
{{< piratify >}}