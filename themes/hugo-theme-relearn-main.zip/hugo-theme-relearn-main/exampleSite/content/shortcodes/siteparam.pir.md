+++
description = "Get value o' ship parrrams varrriables 'n yer plank"
title = "SiteParam"
+++
{{< piratify >}}