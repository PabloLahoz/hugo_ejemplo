+++
aliases = "/pir/cont/icons"
description = "Nice ay'cons fer yer plank"
title = "Icon"
+++
{{< piratify >}}