+++
alwaysopen = false
description = "This be a hidden demo child plank"
hidden = true
tags = ["children", "the hidden"]
title = "plank 4 (hidden)"
weight = 40
+++
{{< piratify >}}