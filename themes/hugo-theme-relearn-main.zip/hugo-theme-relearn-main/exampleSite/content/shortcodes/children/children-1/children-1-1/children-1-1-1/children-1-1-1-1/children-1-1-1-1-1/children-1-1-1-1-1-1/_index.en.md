+++
description = "This is a non-hidden demo child page of a hidden parent page"
tags = ["children", "the hidden"]
title = "page 1-1-1-1-1-1"
+++

This is a **non-hidden** demo child page of a hidden parent page.