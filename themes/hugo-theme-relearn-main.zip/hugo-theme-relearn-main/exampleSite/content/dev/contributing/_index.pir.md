+++
description = "What to know if you want to contribute"
title = "Contributing"
+++
{{< piratify >}}